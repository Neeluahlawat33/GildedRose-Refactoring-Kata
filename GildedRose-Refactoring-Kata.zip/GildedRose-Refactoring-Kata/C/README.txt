run-once.sh runs your tests once

Assumptions:
  - make and a C++ compiler (like gcc) is installed on your system and is in the PATH
  - The CppUTest framework is in the directory CppUTest
