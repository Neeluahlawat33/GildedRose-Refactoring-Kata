GildedRose
=====

It is assumed you have installed Erlang and rebar3.

To run the tests do: `rebar3 as test lfe ltest`.

Checkout the [LFEUnit Emacs plugin](https://github.com/mdbergmann/emacs-lfeunit) when you're on Emacs.

Otherwise the usual rebar3 things apply.
